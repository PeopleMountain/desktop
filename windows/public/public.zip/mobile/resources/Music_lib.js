const music_lib = [
	{key:1,name:"Anna Graceman、Jacoo - Words",src:"Anna Graceman、Jacoo - Words.mp3"},
	{key:2,name:"Ariana Grande - One Last Time",src:"Ariana Grande - One Last Time.mp3"},
	{key:3,name:"Ariana Grande、Nysveen - One Last Time",src:"Ariana Grande、Nysveen - One Last Time.mp3"},
	{key:4,name:"Axel、Faruk Sabanci - Meet Again",src:"Axel、Faruk Sabanci - Meet Again.mp3"},
	{key:5,name:"Olivia O'Brien、gnash - i hate u, i love u",src:"Olivia O'Brien、gnash - i hate u, i love u.mp3"},
	{key:6,name:"Pegato、Eklo - Let's Go Home",src:"Pegato、Eklo - Let's Go Home.mp3"},
	{key:7,name:"Summertime",src:"Summertime.mp3"},
	{key:8,name:"锦零 - 豆花之歌（Cover 仙后）",src:"锦零 - 豆花之歌（Cover 仙后）.mp3"},
	{key:9,name:"北岛诗+-+9277",src:"北岛诗+-+9277.mp3"},
	{key:10,name:"鞠文娴 - BINGBIAN病变 (女声版)",src:"鞠文娴 - BINGBIAN病变 (女声版).mp3"}
]